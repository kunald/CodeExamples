*******************************************************************************
This solution accompanies the July 2013 MSDN Magazine Data Points column
Behavior Driven Design with Specflow and Entity Framework

 by Julie Lerman
msdn.com/magazine

Requires Visual Studio 2012
There is a single solution enclosed: SpecFlowAndEF

Julie Lerman
thedatafarm.com/blog
learnentityframework.com
twitter.com/julielerman
pluralsight.com/training/Authors/Details/julie-lerman