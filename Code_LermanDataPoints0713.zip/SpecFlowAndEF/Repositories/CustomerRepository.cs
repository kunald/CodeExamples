﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
using UnitTestProject1.User_Stories.Add;

namespace Repositories
{
public class CustomerRepository
{
  private CustomerContext _context = new CustomerContext();
  public void Add(Customer customer)
  {
    _context.Customers.Add(customer);
  }

  public int Save()
  {
    return _context.SaveChanges();
  }

  public Customer FindById(int id)
  {
    return _context.Customers.Find(id);
  }
}
}
