namespace UnitTestProject1.User_Stories.Add
{
public class Customer
{
  public int Id { get; set; }
  public string FirstName { get; set; }
  public string LastName { get; set; }
}
}