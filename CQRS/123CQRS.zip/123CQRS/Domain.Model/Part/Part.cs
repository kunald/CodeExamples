﻿using System;
using Insight.Cqrs.Domain;
using Insight.Cqrs.Events;

namespace Domain.Model
{
    public class Part : AggregateRoot,
         IHandle<PartCreatedEvent>
    {
        public string PartNumber { get; private set; }
        public string PartDescription { get; private set; }
        public int UnitOfMeasure { get; private set; }
        public int SalesLeadTime { get; private set; }

        public Part()
        {

        }

        public Part(Guid partId, string partNumber, string partDescription, int unitOfMeasure, int salesLeadTime)
        {
            // Should check for business validation here 
            ApplyChange(new PartCreatedEvent(partId, partNumber, partDescription, unitOfMeasure, salesLeadTime));
        }

        public void Handle(PartCreatedEvent e)
        {
            Id = e.AggregateId;
            SalesLeadTime = e.SalesLeadTime;
            UnitOfMeasure = e.UnitOfMeasure;
            PartDescription = e.PartDescription;
            PartNumber = e.PartNumber;
            Version = e.Version;
        }
    }
}
