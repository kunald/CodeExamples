﻿using Insight.Cqrs.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain.Model
{
    public class CreatePartCommand : Command
    {
        public string PartNumber { get; private set; }
        public string PartDescription { get; private set; }
        public int UnitOfMeasure { get; private set; }
        public int SalesLeadTime { get; private set; }

        public CreatePartCommand(Guid aggregateId, string partNumber, string partDescription, int unitOfMeasure, int salesLeadTime, int version)
            : base(aggregateId, version)
        {
            SalesLeadTime = salesLeadTime;
            UnitOfMeasure = unitOfMeasure;
            PartDescription = partDescription;
            PartNumber = partNumber;
        }
    }
}
