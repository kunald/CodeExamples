﻿using Domain.Model;
using System;
using Insight.Cqrs.Configuration;
using Insight.Cqrs.Storage;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace _123.Tests
{
    [Binding]
    public class AddPartSteps
    {
        Part newPart;
        private Guid tmpGuid;
        private IRepository<Part> irepo;


        [Given(@"a user has entered information about a Part")]
        public void GivenAUserHasEnteredInformationAboutAPart()
        {
            ////newPart = new Part(new Guid(), "PC/1000", "PC", 1, 5);
            tmpGuid = Guid.NewGuid();
            //irepo = new Repository<Part>(new InMemoryEventStorage(new EventBus);
            ServiceLocator.CommandBus.Send(new CreatePartCommand(tmpGuid, "PC/1000", "PC", 1, 5, 123));
            //var handler = new CreatePartCommandHandler(irepo);
            //handler.Execute(new CreatePartCommand(tmpGuid, "PC/1000", "PC", 1, 5, 123));
        }

        [Then(@"that Part should be stored in the system")]
        public void ThenThatPartShouldBeStoredInTheSystem()
        {
            Assert.IsNotNull(ServiceLocator.ReportDatabase.GetById(tmpGuid));
        }
    }
}
