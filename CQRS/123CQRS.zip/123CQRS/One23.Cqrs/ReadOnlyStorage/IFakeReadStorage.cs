﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Insight.Cqrs.ReadOnlyStorage
{
    public interface IFakeReadStorage
    {
        //Object GetById(Guid id);
        //void Add(Object item);
        //void Delete(Guid id);
        //List<Object> GetItems();

        //TODO: implement crud for readonly models based on events of aggregates
    }
}
