using System;

namespace Fohjin.DDD.Events.Account
{
    [Serializable]
    public class AccountClosedEvent : DomainEvent
    {
    }
}