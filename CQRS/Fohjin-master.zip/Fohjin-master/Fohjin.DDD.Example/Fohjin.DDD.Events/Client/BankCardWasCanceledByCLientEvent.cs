﻿using System;

namespace Fohjin.DDD.Events.Client
{
    [Serializable]
    public class BankCardWasCanceledByCLientEvent : DomainEvent
    {
    }
}