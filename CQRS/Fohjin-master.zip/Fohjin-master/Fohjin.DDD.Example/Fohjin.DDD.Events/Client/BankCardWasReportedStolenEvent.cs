﻿using System;

namespace Fohjin.DDD.Events.Client
{
    [Serializable]
    public class BankCardWasReportedStolenEvent : DomainEvent
    {
    }
}