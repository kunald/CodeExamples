﻿using System;

namespace Fohjin.DDD.EventStore.SQLite
{
    public class ConcurrencyViolationException : Exception { }
}