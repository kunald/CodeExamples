namespace Fohjin.DDD.EventStore.Storage.Memento
{
    public interface IMemento
    {
    }
}