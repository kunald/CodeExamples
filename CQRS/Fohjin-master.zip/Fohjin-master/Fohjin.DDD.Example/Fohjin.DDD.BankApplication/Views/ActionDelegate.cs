
namespace Fohjin.DDD.BankApplication.Views
{
    public delegate void EventAction();
}