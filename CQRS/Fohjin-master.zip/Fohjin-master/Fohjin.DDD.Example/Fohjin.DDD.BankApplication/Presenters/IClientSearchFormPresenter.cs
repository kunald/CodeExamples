namespace Fohjin.DDD.BankApplication.Presenters
{
    public interface IClientSearchFormPresenter : IPresenter
    {
    }
}