﻿namespace Fohjin.EventStore
{
    public interface IMemento
    {
    }
}