﻿using System;
using SimpleCqrs.Eventing;

namespace SimpleCQRSDemo.Events
{
    public class AccountCreatedEvent : DomainEvent { }
}