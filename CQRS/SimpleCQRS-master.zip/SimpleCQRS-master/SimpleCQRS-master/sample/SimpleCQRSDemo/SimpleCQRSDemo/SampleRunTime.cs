﻿using SimpleCqrs;
using SimpleCqrs.Unity;

namespace SimpleCQRSDemo
{
    public class SampleRunTime : SimpleCqrsRuntime<UnityServiceLocator> { }
}