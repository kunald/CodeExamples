﻿using System;

namespace SimpleCQRSDemo.ReadModel
{
    public class AccountReadModel
    {
        public string Name { get;  set; }
        public Guid Id { get;  set; }
    }
}