﻿using System.Collections.Generic;

namespace SimpleCQRSDemo.FakeDb
{
    public class FakeAccountTable : List<FakeAccountTableRow>
    { }
}