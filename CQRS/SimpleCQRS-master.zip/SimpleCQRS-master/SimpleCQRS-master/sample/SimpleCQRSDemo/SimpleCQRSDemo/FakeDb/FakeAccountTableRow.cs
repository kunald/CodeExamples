﻿using System;

namespace SimpleCQRSDemo.FakeDb
{
    public class FakeAccountTableRow
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}