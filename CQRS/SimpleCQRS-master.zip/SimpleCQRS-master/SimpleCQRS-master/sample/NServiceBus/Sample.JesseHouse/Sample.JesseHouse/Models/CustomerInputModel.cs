﻿namespace Sample.JesseHouse.Models
{
    public class CustomerInputModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}