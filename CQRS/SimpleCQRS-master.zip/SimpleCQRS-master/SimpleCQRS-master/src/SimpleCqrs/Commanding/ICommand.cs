﻿namespace SimpleCqrs.Commanding
{
    public interface ICommand
    {
    }
}