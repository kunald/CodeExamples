﻿namespace SimpleCqrs.Domain
{
    public interface IRegisterEntities
    {
        void RegisterEntity(Entity entity);
    }
}