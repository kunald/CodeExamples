﻿namespace SimpleCqrs
{
    public interface IRegisterComponents
    {
        void Register(IServiceLocator serviceLocator);
    }
}