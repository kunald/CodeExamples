﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Events.Cafe
{
    public class OrderedItem
    {
        public int MenuNumber;
        public string Description;
        public bool IsDrink;
        public decimal Price;
    }
}
