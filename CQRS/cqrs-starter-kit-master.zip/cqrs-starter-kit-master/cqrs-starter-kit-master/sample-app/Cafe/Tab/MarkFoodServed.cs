﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cafe.Tab
{
    public class MarkFoodServed
    {
        public Guid Id;
        public List<int> MenuNumbers;
    }
}
