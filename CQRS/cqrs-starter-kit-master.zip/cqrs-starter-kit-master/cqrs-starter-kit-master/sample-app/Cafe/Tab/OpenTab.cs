﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cafe.Tab
{
    public class OpenTab
    {
        public Guid Id;
        public int TableNumber { get; set; }
        public string Waiter { get; set; }
    }
}
