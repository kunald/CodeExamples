﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Events.Cafe;

namespace Cafe.Tab
{
    public class PlaceOrder
    {
        public Guid Id;
        public List<OrderedItem> Items;
    }
}
