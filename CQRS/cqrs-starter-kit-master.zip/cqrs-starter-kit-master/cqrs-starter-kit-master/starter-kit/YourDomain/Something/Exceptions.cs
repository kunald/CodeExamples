﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YourDomain.Something
{
    public class SomethingCanOnlyHappenOnce : Exception
    {
    }
}
