﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YourDomain.Something
{
    public class MakeSomethingHappen
    {
        public Guid Id;
        public string What;
    }
}
