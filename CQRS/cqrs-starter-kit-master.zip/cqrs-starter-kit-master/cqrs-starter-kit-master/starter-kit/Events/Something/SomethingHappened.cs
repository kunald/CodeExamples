﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Events.Something
{
    public class SomethingHappened
    {
        public Guid Id;
        public string What;
    }
}
